package Geometry;

public interface Computable {
	double PI=3.1428;//by default public static final
	double area();//by default public abstract
	double perimeter();//by default public abstract
}
